import React from "react"
import Nav from './Comp/Navbar/Nav'
import Admin from "./Pages/Admin/Admin"

const App=()=> {

  return (
    <div>
<Nav/>
<Admin/>

    </div>
  )
}

export default App
