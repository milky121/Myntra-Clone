export const Homelivingbanner=[
    { id: 1, url: "https://assets.myntassets.com/f_webp,w_980,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/6/8/eff01060-f706-468d-b97c-95cdf43174f91528443826867-Desktop-Home-Banner.jpg" },

     { id: 2, url: "https://myntra-clone-karan.netlify.app/images/home%20n%20living.webp" },

    
]

export const Homeliving=[
    { id: 1, url: "https://assets.myntassets.com/f_webp,w_350,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/2/11517563660020-bed.jpg" },

     { id: 2, url: "https://assets.myntassets.com/f_webp,w_350,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/2/11517563782565-furnishings.jpg" },

     { id: 3, url: "https://assets.myntassets.com/f_webp,w_350,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/2/11517563810789-art-n-decor.jpg" },

     { id: 4, url: "https://assets.myntassets.com/f_webp,w_350,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/2/11517563866590-lamps.jpg" },

]

export const Homelivingbanner2= { id: 1, url: "https://assets.myntassets.com/f_webp,w_980,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/1/11517478281102-Home-page-Desktop_12.jpg" }


export const Homeliving2=[
    { id: 1, url: "https://assets.myntassets.com/f_webp,w_326,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/1/11517485441956-Wedding-checklist.jpg" },
    { id: 2, url: "https://assets.myntassets.com/f_webp,w_326,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/1/11517478592904-Home-page-Desktop_14.jpg" },
    { id: 3, url: "https://assets.myntassets.com/f_webp,w_326,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2018/2/1/11517478592892-Home-page-Desktop_15.jpg" },

]


 export const Homeliving3=[ 
    { id: 1, url: "https://assets.myntassets.com/f_webp,w_196,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2019/3/1/dc2450db-d76d-4d2e-b937-49c0c68ed7f01551443106510-Home-page-Desktop-Brands_09.jpg" },

    { id: 2, url: "https://assets.myntassets.com/f_webp,w_196,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2019/3/1/99c57d52-b50e-4e2e-9582-cb839543ab071551443106488-Home-page-Desktop-Brands_10.jpg" },

    { id: 3, url: "https://assets.myntassets.com/f_webp,w_196,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2019/3/1/9e5a0444-409f-40a3-b199-d4b0b43f94fc1551443106478-Home-page-Desktop-Brands_11.jpg" },

    { id: 4, url: "https://assets.myntassets.com/f_webp,w_196,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2019/3/1/e90b8666-20da-4bd0-8885-235859c0947f1551443106467-Home-page-Desktop-Brands_12.jpg" },

    { id: 5, url: "https://assets.myntassets.com/f_webp,w_196,c_limit,fl_progressive,dpr_2.0/assets/images/banners/2019/3/1/a38e440e-1ff7-4092-acbe-46d74b38384a1551443106457-Home-page-Desktop-Brands_13.jpg" }
]