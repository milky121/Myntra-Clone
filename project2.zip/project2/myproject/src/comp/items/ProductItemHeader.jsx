// import { Box, styled } from "@mui/material";



// const Div2=styled(Box)`
// margin:10px 20px;
// font-size:15px;
// &> span{
//   font-weight:bold;
// }
// `


// const ProductItemHeader=(props)=>{
//     const {product}=props;
//     return(
//         <Box>
          
//     <Div2>Home/Clothing/<span>{product.category}</span></Div2>
//     <Div2><span>Man Shirts</span>- 400</Div2>
//         </Box>
//     )
// }
// export default ProductItemHeader;
